#!/usr/bin/env python
# coding: utf-8

import requests, os

def update_tracker(url, timeout):
    headers = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36 Edg/80.0.361.111"}
    response = requests.get(url=url, headers=headers, timeout=timeout)
    trcaker = response.text
    return trcaker

def write2conf(tracker, aria2_folder):
    conf_path = os.path.join(aria2_folder, "aria2.conf")
    with open(conf_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    with open(conf_path, "w", encoding="utf-8") as f:
        for line in lines:
            if "bt-tracker" in line:
                line = "bt-tracker={}".format(tracker)
            f.write(line)

def start_aria2c(aria2_folder):
    aria2c_path = os.path.join(aria2_folder, "aria2c.exe")
    conf_path = os.path.join(aria2_folder, "aria2.conf")
    cmd = "{} --conf-path={}".format(aria2c_path, conf_path)
    os.system(cmd)

def creat_sessions(aria2_folder):
    session_file_path = os.path.join(aria2_folder, "aria2.session")
    aria2_log_path = os.path.join(aria2_folder, "aria2.log")
    if not os.path.exists(session_file_path):
        session_file = open(session_file_path, "w", encoding="utf-8")
        session_file.close()
    if not os.path.exists(aria2_log_path):
        aria2_log = open(aria2_log_path, "w", encoding="utf-8")
        aria2_log.close()
    


if __name__ == "__main__":
    aria2_folder = "C:\\SoftWare\\Download\\Aria2"
    url = "https://raw.githubusercontent.com/XIU2/TrackersListCollection/master/best_aria2.txt"
    timeout = 3
    creat_sessions(aria2_folder)
    tracker = update_tracker(url, timeout)
    write2conf(tracker, aria2_folder)
    
    try:
        start_aria2c(aria2_folder)
    except KeyboardInterrupt:
        print("[++] aria2c 服务已经安全停止 ...")
        os.system("pause")
